mainMenu {
    enabled = true
    label {
        position {
            x = 2
            y { it - 20 }
        }
        text = literal("XPlus OptiFineReady based on Minecraft 1.18.2 (Fabric)")
        align = "left"
        color = 0xFFFFFF
        hoveredColor = 0xED623D
        shadow = true
        onClicked = url("https://www.curseforge.com/minecraft/modpacks/xplus-2-0-modpack-fabric")
    }
}